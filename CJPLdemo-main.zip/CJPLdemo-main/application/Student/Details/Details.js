import { StatusBar } from 'expo-status-bar';
import React ,{useEffect,useState} from "react";
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';
import {useRoute} from '@react-navigation/native'; 


export default function Details({navigation}) {

    const route = useRoute();

  return (
      <View style={styles.mainContainer}>
          <Text style={styles.studentEnrollHeading}>Student Enrollment</Text>
          <View style={styles.card}>
              <ScrollView>
                  <View style={styles.studentName}>
                      <Text style={styles.myName}>{route.params.name}</Text>
                      <Image
                          style={{ width: 125, height: 125, alignItems: 'center', marginBottom: 24 }}
                          resizeMode='cover'
                          source={{ uri: route.params.image }} />
                  </View>
                  <View style={styles.studentDetails}>
                      <Text style={styles.candidateId}>Enrollment ID: </Text>
                      <Text style={styles.cand_id}>{route.params.id}</Text>
                      <Text style={styles.candidateId}>E-mail:</Text>
                      <Text style={styles.cand_id}>{route.params.email}</Text>
                      <Text style={styles.candidateId}>M0bile:</Text>
                      <Text style={styles.cand_id}>{route.params.mobile}</Text>
                      <Text style={styles.candidateId}>Website:</Text>
                      <Text style={styles.cand_id}>{route.params.website}</Text>
                      <Text style={styles.candidateId}>Description:</Text>
                      <Text style={styles.cand_id}>{route.params.description}</Text>
                      <Text style={styles.candidateId}>Date of Birth</Text>
                      <Text style={styles.cand_id}>{route.params.mobile}</Text>
                      <Text style={styles.candidateId}>Parent Name</Text>
                      <Text style={styles.cand_id}>{route.params.description}</Text>
                      <Text style={styles.candidateId}>Code-Centre:</Text>
                      <Text style={styles.cand_id}>{route.params.mobile}</Text>
                      <Text style={styles.candidateId}>Code-ManageIdproof ID</Text>
                      <Text style={styles.cand_id}>{route.params.mobile}</Text>
                      <Text style={styles.candidateId}>Proof ID number</Text>
                      <Text style={styles.cand_id}>{route.params.mobile}</Text>
                      <Text style={styles.candidateId}>Phone Number</Text>
                      <Text style={styles.cand_id}>{route.params.mobile}</Text>
                      <Text style={styles.candidateId}>Address</Text>
                      <Text style={styles.cand_id}>{route.params.description}</Text>
                      <Text style={styles.candidateId}>City</Text>
                      <Text style={styles.cand_id}>{route.params.description}</Text>
                      <Text style={styles.candidateId}>State</Text>
                      <Text style={styles.cand_id}>{route.params.description}</Text>
                      <Text style={styles.candidateId}>Zip</Text>
                      <Text style={styles.cand_id}>{route.params.description}</Text>
                      <Text style={styles.candidateId}>Country</Text>
                      <Text style={styles.cand_id}>{route.params.description}</Text>
                      <StatusBar style="auto" />
                  </View>
              </ScrollView>
          </View>
      </View>
      );
}

const styles = StyleSheet.create({
    mainContainer:{
        width:'100%',
        padding:20,
        flex: 1,
        justifyContent:'space-between',
        alignItems:'center',
    },
    studentEnrollHeading:{
        fontFamily: 'Nunito Sans, sans-serif',
        fontWeight: '600',
        fontSize: 24,
        color: '#262B40',
        marginBottom: 16
    },
    card:{
        backgroundColor:'white',
        borderRadius:15,
        marginVertical:'20',
        flex: 1,
        flexDirection:'column',
        borderColor: '#d1d7e0',
        borderWidth: 1,
        justifyContent:'space-between',
        alignItems:'center',
        padding:20,
    },
    studentName:{
        alignItems:'center',
    },
    myName:{
        fontFamily: 'Nunito Sans, sans-serif',
        fontSize: 18,
        fontWeight:'600',
        color:'#262B40',
        flex: 1,
        textTransform:'uppercase',
        alignItems:'center',
        paddingBottom: 10
    },
    candidateId:{
        fontFamily: 'Nunito Sans, sans-serif',
        fontWeight: '600',
        fontSize: 16,
        color: '#262B40',
        paddingTop: 0,
        paddingBottom: 6
    },
    cand_id:{
        fontFamily: 'Nunito Sans, sans-serif',
        fontSize: 16,
        color:'#66799e',
        fontWeight:'400',
        borderColor: '#d1d7e0',
        borderWidth: 1,
        borderRadius: 10,
        padding: 10,
        marginBottom: 30
    }
});