import React ,{useEffect,useState} from "react";
import { FlatList, Text, StyleSheet, View , Image, ActivityIndicator, TouchableOpacity, ScrollView} from "react-native";

// import menuicon from '../assets/three_dot_menu.png';

const Database = ({navigation}) => {
    
    const [myUserData,setMyUserData]=useState();
    const [isLoaded, setIsLoaded]=useState(true);
    
    const getUserData =async ()=>{
        try{
            const response = await fetch(
                "https://thapatechnical.github.io/userapi/users.json"
            );
            const myData =await response.json();
            setMyUserData(myData);
            setIsLoaded(false);
            console.log(myData);
        }
        catch(error){
            console.log(error);
        }
    };
   
    useEffect(()=>{
        getUserData();
    },[]);

    return(
        <View>
        {isLoaded ? (
        <View style={styles.loader}>
            <ActivityIndicator size='large' color='#000ff'/>
        </View>):
        (<View>
                <Text style ={styles.mainHeader}>List of Students </Text>
                <FlatList
                data ={myUserData}
                renderItem={({item})=>{
                    console.log(item.image);
                    const imgPress=()=>{
                        navigation.navigate('Details',{
                            id: item.id,
                            name: item.name,
                            website: item.website,
                            description: item.description,
                            mobile: item.mobile,
                            email: item.email,
                            image:item.image,
                    });
                    };
                    return(
                        <View style={styles.studentDetailsContainer}>
                            <View style={styles.studentDetailsBox}>
                                <View style={{flex:1,flexDirection:'column',alignItems:'center'}}>
                                    <Image
                                    style={{width:50,height:50,borderRadius:50,flex:1}}
                                    resizeMode='cover'
                                    source={{uri: item.image}}/>
                                </View>
                                <View style={{flex:2,flexDirection:'column'}}>
                                        <Text style={styles.myName}>{item.name}</Text>
                                        <Text style ={styles.myName}>{item.id} </Text>
                                </View>
                                <View style={{flex:2,flexDirection:'column'}}>
                                        <Text style={styles.myName}>{item.email}</Text>
                                        <Text style={styles.myName}>{item.mobile}</Text>
                                </View>
                                <View style={{flex:1,flexDirection:'column', justifyContent:'flex-end',alignItems:'center'}}>
                                <TouchableOpacity onPress={imgPress}>
                                    {/* <Image
                                    style={{width:50,height:30,flex:1,display:'flex'}}
                                    resizeMode='contain'
                                    source={{uri: '../assets/three_dot_menu.png'}}/> */}
                                    <Text style={styles.threeDots}>...</Text>
                                </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                    );
                }}
                />
            </View>
            )}
        </View>
    );
};

const styles =StyleSheet.create({
    loader:{
        minHeight:'100%',
        flex: 1,
        justifyContent:'center',
        alignItems:'center',
    },
    studentDetailsContainer:{
        paddingLeft:10,
        paddingRight:10,
        paddingTop: 5,
        paddingBottom:5
    },
    mainHeader:{
        fontSize: 16,
        color:'#fff',
        fontWeight:'600',
        backgroundColor:'#262B40',
        fontFamily: 'Nunito Sans, sans-serif',
        textAlign:'center',
        paddingTop: 10,
        paddingBottom: 10,
        marginBottom: 10
    },
    studentDetailsBox:{
        flex:1,
        flexDirection:'row',
        backgroundColor:'white',
        borderRadius:20,
        borderColor: '#d1d7e0',
        borderWidth: 1,
        alignItems:'center',
        justifyContent:'space-between',
        paddingTop: 10,
        paddingBottom: 10
    },
    myName:{
        fontSize: 14,
        color:'#262B40',
        fontFamily: 'Nunito Sans, sans-serif',
        paddingBottom: 10
    },
    threeDots:{
        fontSize: 20,
        fontWeight: '900',
        color:'#262B40',
        fontFamily: 'Nunito Sans, sans-serif',
    }
});

export default Database;