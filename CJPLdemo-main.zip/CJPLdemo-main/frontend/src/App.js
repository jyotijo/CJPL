import { BrowserRouter as Router } from "react-router-dom";
import Routes from "./routes/index";
import * as All from "./import_file/index";
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.scss';
import './Common.scss';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes />
      </Router>
    </div>
  );
}

export default App;
