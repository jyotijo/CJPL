import React from 'react';
import './Dashboard.scss';


const DashboardPage = () => {
    return (
        <div className='dashboard-container'>
            <div className="dashboard-view">
                <div className="common-heading">Examination Dashboard</div>
                <div className="breadcrumb">Home / Examination Dashboard</div>
                
                <div className='container-xxl'>
                    <div className='row align-items-center'>
                        <div className='col-sm-2 col-md-3'>
                            <div class="input-wrapper">
                                <label for="first">First</label>
                                <select>
                                    <option>Examination 1 to 10</option>
                                    <option>Examination 1 to 10</option>
                                </select>
                            </div>
                        </div>
                        <div className='col-sm-2 col-md-3'>
                            <div class="input-wrapper">
                                <label for="first">Date</label>
                                <select>
                                    <option>Examination 1 to 10</option>
                                    <option>Examination 1 to 10</option>
                                </select>
                            </div>
                        </div>
                        <div className='col-sm-2 col-md-3'>
                            <div class="input-wrapper">
                                <label for="first">Shift</label>
                                <select>
                                    <option>Examination 1 to 10</option>
                                    <option>Examination 1 to 10</option>
                                </select>
                            </div>
                        </div>
                        <div className='col-sm-2 col-md-2'>
                            <div class="input-wrapper">
                                <label for="first">Centers</label>
                                <select>
                                    <option>Examination 1 to 10</option>
                                    <option>Examination 1 to 10</option>
                                </select>
                            </div>
                        </div>
                        <div className='col-sm-4 col-md-2 submit-btn'>
                            <button type="button" class="btn btn-success">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default DashboardPage;