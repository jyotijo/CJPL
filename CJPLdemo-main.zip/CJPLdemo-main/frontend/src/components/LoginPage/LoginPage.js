import React from 'react';
import './LoginPage.scss';


const LoginPage = () => {
    return (
        <div className='login-container'>
            <div className="login-view">
                <h1>Login Page Form</h1>
            </div>
        </div>
    )
}

export default LoginPage;