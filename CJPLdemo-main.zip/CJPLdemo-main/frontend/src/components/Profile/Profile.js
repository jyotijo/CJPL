import React from 'react';
import './Profile.css';


const ProfilePage = () => {
    return (
        <div className='profile-container'>
            <div className="profile-view">
                <h1>Profile</h1>
            </div>
        </div>
    )
}

export default ProfilePage;