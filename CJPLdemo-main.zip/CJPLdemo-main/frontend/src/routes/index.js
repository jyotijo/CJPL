import { useEffect, useState } from "react";
import { SideMenu, LoginPage, ProfilePage, DashboardPage  } from "../import_file/index";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

const Dashboard = () => <h1>Dashboard</h1>;

function AppRoutes() {
  const [inactive, setInactive] = useState(false);

  let pathName = window.location.pathname;
  let arr = pathName.toString().split("/");
  let currentPath = arr[arr.length-1];

  return (
    <div className="App">
      <Router>
      {currentPath.length > 0 && 
        <SideMenu
          onCollapse={(inactive) => {
            console.log(inactive);
            setInactive(inactive);
          }}
        /> }

        <div className={`container ${inactive ? "inactive" : ""}`}>
          <Switch>
          <Route exact path={"/"}>
                <LoginPage />
            </Route>
            <Route exact path={"/dashboard"}>
                <DashboardPage/>
            </Route>
            <Route exact path={"/profile"}>
                <ProfilePage/>
            </Route>

            {/* <Route exact path={"/"} element={<ProfilePage />}/> */}
            
          </Switch>
        </div>
      </Router>
    </div>
  );
}

export default AppRoutes;