import SideMenu from "../components/SideMenu";
import MenuItem from "../components/MenuItem";
import LoginPage from "../components/LoginPage/LoginPage";
import DashboardPage from "../components/Dashboard/Dashboard";
import ProfilePage from "../components/Profile/Profile";

export {
    SideMenu,
    MenuItem,
    LoginPage,
    DashboardPage,
    ProfilePage
}