const date = require('date-and-time');
const mongoose = require('mongoose');
const Exam = require('./exam.model');
const { Schema } = mongoose;

const imageSchema = new Schema({
    name: String,
    desc: String,
    img:
    {
        data: Buffer,
        contentType: String
    }
});

const studentSchema = new Schema({

    centerCode: {
        type: String,
        required: true,

    },
    examIds: [{
        type: mongoose.SchemaTypes.ObjectId,
        ref: "Exam",
    }],
    examCode: {
        type: String,
    },
    studentName: {
        type: String,
        required: true,
        //maxLength: 20


    },
    parentName: {
        type: String,
        required: true,
        maxLength: 20


    },
    enrollmentId: {
        type: String,
        unique: true,
        required: true,
        immutable: true,
        maxLength: 20


    },
    IDproof: {
        type: String,
        required: true,
        // maxLength: 20


    },
    IDproofNumber: {
        type: String,
        required: true,
        // maxLength: 20


    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    examType: {
        type: String,
        required: true,
        maxLength: 10

    },
    examShift: {
        type: String,
        required: true,
        //maxLength: 16

    },

    address: {
        type: String
    },
    city: {
        type: String,
        required: true,
    },
    state: {
        type: String,
        required: true,
    },
    zipcode:
    {
        type: Number,
        minLength: 6,
        required: true,
    },
    country: {
        type: String,
        required: true,

    },
    contactNumber: {
        type: Number,
        minLength: 10,
        maxLength: 10,

    },
    examDate: {
        type: Date,
    },
    image: {
        name: String,
        desc: String,
        img:
        {
            data: Buffer,
            contentType: String
        }
    },

    created_at: {
        type: Date,
        immutable: true,
        default: Date.now()

    },
    updated_at: {
        type: Date,
        default: Date.now

    }


});


studentSchema.set("toJSON", {
    transform: (document, returnedObject) => {
        returnedObject.id = returnedObject._id.toString();
        returnedObject.examDate = date.format(new Date(returnedObject.examDate), 'DD-MM-YYYY hh:mm A [GMT]Z ');
        returnedObject.created_at = date.format(new Date(returnedObject.created_at), 'DD-MM-YYYY hh:mm A [GMT]Z ');
        returnedObject.updated_at = date.format(new Date(returnedObject.updated_at), 'DD-MM-YYYY hh:mm A [GMT]Z ');
        delete returnedObject._id;
        delete returnedObject.__v;

    }
});


const Student = mongoose.model("student", studentSchema);


module.exports = Student