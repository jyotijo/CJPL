const date = require('date-and-time');
const mongoose = require('mongoose');
const Exam = require('../models/exam.model');
const { Schema } = mongoose;

const addressSchema = new Schema({

    address: String,
    city: {
        type: String,
        required: true,
    },
    state: {
        type: String,
        required: true,
    },
    zipcode:
    {
        type: Number,
        minLength: 6,
        required: true,
    },
    country:{
        type: String,
        required: true,

    } 
})

const centerSchema = new Schema({
    centerCode: {
        type: String,
        required: true,
        unique: true,
        immutable: true,
    },
    examIds: [{
        type: mongoose.SchemaTypes.ObjectId,
        ref: "Exam",
    }],
    examCode: {
        type: String,
    },
    centerHead: {
        type: String,
        required: true,
        maxLength: 20


    },
    centerName: {
        type: String,
        required: true,
        //maxLength: 16

    },
    centerAddress:   
                addressSchema,

    centerStatus: {
        type: String,
        required: true,
        //default:'Inactive'

    },
    contactPersonName:{
        type: String
    },
    contactNumber: {
        type: Number,
        minLength: 10,
        maxLength: 10,

    },
    examDate: {
        type: Date,
    },

    created_at:{
        type: Date,
        immutable:true,
        default: Date.now()

    },
    updated_at:{
        type: Date,
        default: Date.now

    }
      
    
});


centerSchema.set("toJSON", {
    transform: (document, returnedObject) => {
        returnedObject.id = returnedObject._id.toString();
        returnedObject.examDate = date.format(new Date(returnedObject.examDate), 'DD-MM-YYYY hh:mm A [GMT]Z ');
        returnedObject.created_at = date.format(new Date(returnedObject.created_at), 'DD-MM-YYYY hh:mm A [GMT]Z ');
        returnedObject.updated_at = date.format(new Date(returnedObject.updated_at), 'DD-MM-YYYY hh:mm A [GMT]Z ');
        delete returnedObject._id;
        delete returnedObject.__v;

    }
});


const Center = mongoose.model("center", centerSchema);
module.exports = Center;