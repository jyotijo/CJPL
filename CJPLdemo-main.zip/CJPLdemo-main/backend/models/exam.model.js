const date = require('date-and-time');
const mongoose = require('mongoose');
const Center = require('../models/center.model');
const { Schema } = mongoose;

const ExamSchema = new Schema({
    examCode:{
        type: String,
        required: true,
        unique:true,
        immutable:true,
       // maxLength: 16
    },
    customerCode:{
        type: String,
        required: true,
    },
    examType:{
        type: String,
        required: true,
        maxLength: 10
       // default:'MOCK'

    },
    examName:{
        type: String,
        required: true,
        maxLength: 16
        
    },
    examStatus:{
        type: String,
        required:true,
       // default:'Inactive'

    },
    centerIds:[{
        type:mongoose.SchemaTypes.ObjectId,
        ref:"Center",
    }],
    examStartDate:{
      type: Date,
    },
    examEndDate:{
    type: Date,
    },
    examCreatedDate:{
      type: Date,
      immutable:true,
      default: Date.now(),
      
    },    
    examUpdatedDate:{
        type: Date,
        default: Date.now(),
    }
});


ExamSchema.set("toJSON",{
    transform:(document,returnedObject)=>{
        returnedObject.id = returnedObject._id.toString();
        returnedObject.examStartDate = date.format(new Date(returnedObject.examStartDate),'DD-MM-YYYY hh:mm A [GMT]Z ');
        returnedObject.examEndDate = date.format(new Date(returnedObject.examEndDate),'DD-MM-YYYY hh:mm A [GMT]Z ');
        returnedObject.examCreatedDate = date.format(new Date(returnedObject.examCreatedDate),'DD-MM-YYYY hh:mm A [GMT]Z ');
        returnedObject.examUpdatedDate = date.format(new Date(returnedObject.examUpdatedDate),'DD-MM-YYYY hh:mm A [GMT]Z ');
        
        delete returnedObject._id;
        delete returnedObject.__v;
    
    }
});


const Exam = mongoose.model("exam",ExamSchema);
module.exports = Exam ;