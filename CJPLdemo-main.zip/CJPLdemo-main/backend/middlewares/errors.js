const errorHandler = (err,req,res,next) =>{
    console.log("inside error handler :"+err.message +"error status"+err.status);

    if(typeof err === "string"){
        console.log(err.message)
        return res.status(400).json({msg: err.message})
    }

    if(typeof err === "ValidationError"){
        console.log(err.message)
        return res.status(400).json({msg: err.message})
    }

    if(typeof err === "UnauthorizedError"){
        console.log(err.message)
        return res.status(401).json({msg: err.message})
    }
    
   
    
    err.status = err.status || 500;
    return res.status(err.status).json({msg:err.message});

}

module.exports = errorHandler