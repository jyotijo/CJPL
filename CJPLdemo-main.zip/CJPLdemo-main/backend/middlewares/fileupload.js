var multer = require('multer');
const path = require('path');

const fileStorageEngine = multer.diskStorage({
  // destination: './upload/images' ,
  destination: (req, file, cb) => {
    cb(null, 'upload/images')
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname)


  }
});

const upload = multer({
  storage: fileStorageEngine,
  limits: { fileSize: 1000000 },
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|gif/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test((file.originalname).split(".")[1]);
    if (mimetype && extname) {
      cb(null, true);
    }
    else {
      console.log("The file should be an image  ")
      return cb(null, false);
      //return cb("Error: The file should be an image");

    }

  }
}).single('testImage');

module.exports = { upload };