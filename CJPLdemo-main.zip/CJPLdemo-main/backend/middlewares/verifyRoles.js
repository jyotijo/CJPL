const verifyRoles = (...allowedRoles) => {
    return (req, res, next) => {
        console.log("inside verify roles:  "+req.body?.roles);
        if (!req.body?.roles) return res.sendStatus(401);
        const rolesArray = [...allowedRoles];
        const result = req.body.roles.map(role => rolesArray.includes(role)).find(val => val === true);
        console.log("ROLE found :"+result);
        if (!result) return res.sendStatus(401);
        next();
    }
}

module.exports = {verifyRoles}