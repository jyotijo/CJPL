const Center = require('../models/center.model');
const Exam = require('../models/exam.model');
const date = require('date-and-time');

//create new Center

const createCenter = async (req, res, next) => {
    try {

        const examCode = req.params.id;

        const foundExam = await Exam.findOne({ examCode });
        if (!foundExam) return res.status(400).send({
            message: `Exam not Found , You can not create Center for this ExamCode  ${examCode}`
        }); //Exam Not Found

        if (foundExam != null) {

            req.body.examIds = foundExam._id;
            req.body.examCode = foundExam.examCode;
            
            let country = changeCaseFirstLetter(req.body.centerAddress.country);
            req.body.centerAddress.country = country

            let centerStatus = changeCaseFirstLetter(req.body.centerStatus);
            if (centerStatus != "Active" && centerStatus != "Inactive") {
                return res.status(422).send({
                    message: "Center Status must be Active or Inactive",
                })
            }
            req.body.centerStatus = centerStatus
            

            let state = changeCaseFirstLetter(req.body.centerAddress.state);
            req.body.centerAddress.state = state;

            const zipcode = req.body.centerAddress.zipcode;
           
            if(validateZipCode(zipcode))
            {
                req.body.centerAddress.zipcode = zipcode;
            }
            else{

                return res.status(422).send({
                    message: "ZipCode should be of 6 digits and should not contain any spaces",
                })

            }

            const phoneNumber = req.body.contactNumber;
           
            if(validatePhoneNumber(phoneNumber))
            {
                req.body.contactNumber = phoneNumber;
            }
            else{

                return res.status(422).send({
                    message: "Contact Number should be of 10 digits, must starts with [6-9] and it should not contain any spaces",
                })

            }
           
            
            const centerCode = req.body.centerCode;
            const foundCenter = await Center.findOne({ centerCode });
            if (foundCenter) {
                res.send({
                    message: "Center already exists ",

                })

            }
            else {

                let center = new Center(req.body);
                center = await center.save();

                res.send({
                    message: "Center Created",
                    data: center
                })
            }

        }


    } catch (error) {
        return next(error)

    }
}

const updateCenter = async (req, res, next) => {
    try {

        const examCode = req.params.id;

        const foundExam = await Exam.findOne({ examCode });
        if (!foundExam) return res.status(400).send({
            message: `Exam not Found `
        }); //Exam Not Found

        if (foundExam != null) {

            req.body.examCode = foundExam.examCode;
            let country = changeCaseFirstLetter(req.body.country);
            req.body.country = country
            let centerStatus = changeCaseFirstLetter(req.body.centerStatus);


            if (centerStatus != "Active" && centerStatus != "Inactive") {
                return res.status(422).send({
                    message: "Center Status must be Active or Inactive",
                })
            }

            req.body.centerStatus = centerStatus;

            const zipcode = req.body.centerAddress.zipcode;
           
            if(validateZipCode(zipcode))
            {
                req.body.centerAddress.zipcode = zipcode;
            }
            else{

                return res.status(422).send({
                    message: "ZipCode should be of 6 digits and should not contain any spaces",
                })

            }

            const phoneNumber = req.body.contactNumber;
           
            if(validatePhoneNumber(phoneNumber))
            {
                req.body.contactNumber = phoneNumber;
            }
            else{

                return res.status(422).send({
                    message: "Contact Number should be of 10 digits, must starts with [6-9] and it should not contain any spaces",
                })

            }

            const centerCode = req.params.centerId;
           
            const foundCenter = await Center.findOne({ centerCode });
          
            if (foundCenter) {
                    const updatedCenter = await Center.findOneAndUpdate({ "centerCode": centerCode },{ $set: req.body }, { new: true });
                    res.send({
                        message: " Center Updated",
                        data: updatedCenter
                    })
            }
            else {

              res.send({
                    message: " Center not Found"

                })
            }

        }


    } catch (error) {
        return next(error)

    }
}

const getAllCenter = async (req, res, next) => {

    try {
        const examCode = req.params.id;

        const foundExam = await Exam.findOne({ examCode });
        if (!foundExam) return res.status(400).send({
            message: `Exam not Found `
        }); //Exam Not Found

        console.log("Inside services getALL centers ::")


        let centers = [];
        centers = await Center.find({examCode : examCode});
        if (centers.length > 0) {
            console.log("after retrieving.." + centers);
            return res.status(200).send({
                message: "Success",
                data: centers
            })
        }
        else {

            return res.status(404).send({
                message: "No Center Available"
            })

        }

    } catch (error) {
        return next(error)

    }

}


//delete Center
const deleteCenter = async (req, res, next) => {
    try {

        const examCode = req.params.id;
        const centerCode = req.params.centerId;
        const examFound = await Exam.findOne({ examCode: examCode });
        if (!examFound) {
            return res.status(404).send({
                message: "Exam Record Not Found"
            })
        }
        else {

            await Center.findOneAndDelete({ "centerCode": centerCode })

            return res.status(200).send({
                message: "Center Deleted",

            })
        }
    } catch (error) {

        return next(error)

    }


}

//delete Center
const deleteAllCenter = async (req,res, next) => {
    try {
       
        const examCode = req.params.id;
       // const centerCode = req.params.centerId;
        const examFound = await Exam.findOne({ examCode: examCode });
        if (!examFound) {
            return res.status(404).send({
                message: "Exam Record Not Found"
            })
        }
        else {
            console.log("inside services examcode:"+examCode)
            await Center.deleteMany({ "examCode": examCode })

           return res.status(200).send({
                message: `All centers of Exam Code ${examCode}  are deleted`,

            })
        }
    } catch (error) {

        return next(error)

    }


}

const changeCaseFirstLetter = (inputString) => {
    if (typeof inputString === 'string') {
        return inputString.charAt(0).toUpperCase() + inputString.slice(1);
    }
    return null;
}


const validatePhoneNumber = (inputPhone) => {
    let regx = /^[6-9]\d{9}$/;
    return regx.test(inputPhone);
}

const validateZipCode = (inputZipCode) => {
    let regx = /^[1-9][0-9]{5}$/;
    return regx.test(inputZipCode);
}

const validateName = (inputName) => {
    let regx = /^[a-zA-Z ]*$/;
    return regx.test(inputName);
}

module.exports = {
    createCenter,
    deleteCenter,
    updateCenter,
    getAllCenter,
    deleteAllCenter


};