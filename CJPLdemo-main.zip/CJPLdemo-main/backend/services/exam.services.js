const Exam = require('../models/exam.model');
const date = require('date-and-time');
const centerServices = require('../services/center.services');
//A Unique Hexatridecimal ID generator
//const uniqid = require('uniqid');


//create new exam

const createNewExam = async (req, res, next) => {
    try {

        // req.body.examCode = uniqid(`${req.body.examName}_`);
        // console.log(uniqid());
        let examStatus = changeCaseFirstLetter(req.body.examStatus);
        let examType = changeCaseFirstLetter(req.body.examType);
        

        if (examStatus != "Active" && examStatus != "Inactive") {
            return res.status(400).send({
                message: "Exam Status must be Active or Inactive",
            })
        }


        req.body.examStatus = examStatus;
        req.body.examType = examType;
        let exam = new Exam(req.body);
        exam = await exam.save();
        res.send({
            message: "New Exam Created",
            data: exam
        })


    } catch (error) {
        return next(error)

    }
}




//update exam
const updateSingleExam = async (req, res, next) => {
    try {

        const examCode = req.params.id;
               
        let examStatus = changeCaseFirstLetter(req.body.examStatus);
        let examType = changeCaseFirstLetter(req.body.examType);
        

        if (examStatus != "Active" && examStatus != "Inactive") {
            return res.status(400).send({
                message: "Exam Status must be Active or Inactive",
            })
        }

        req.body.examStatus = examStatus;
        req.body.examType = examType;

        const examFound = await Exam.findOne({ examCode: examCode });
        if (!examFound) {
            return res.status(404).send({
                message: "Exam Record Not Found"
            })
        }
        else {

            const updatedExam = await Exam.findOneAndUpdate({ "examCode": examCode }, { $set: req.body }, { new: true });
            return res.status(200).send({
                message: "Exam Record Updated",
                data: updatedExam

            })
        }

    } catch (error) {
        return next(error)

    }

}

//delete Exam
const deleteSingleExam = async (req, res, next) => {
    try {

        let examCode = req.params.id;
        const examFound = await Exam.findOne({ examCode: examCode });
        if (!examFound) {
            return res.status(404).send({
                message: "Exam Record Not Found"
            })
        }
        else {

           
            await centerServices.deleteAllCenter(req,res,next);
            await Exam.findOneAndDelete({ "examCode": examCode })
           
           

            return res.status(200).send({
                message: "Exam Record Deleted",

            })


        }
    } catch (error) {

        return next(error)

    }


}

const findAllcenters = ()=>{
  //  Exam.find()
   // .populate('centers')
   // .then(centers=>console.log(centers))
   // .catch(error=>console.log(error));
}

const changeCaseFirstLetter = (inputString) => {
    if (typeof inputString === 'string') {
        return inputString.charAt(0).toUpperCase() + inputString.slice(1);
    }
    return null;
}

module.exports = {
    createNewExam,
    deleteSingleExam,
    updateSingleExam

};