const Center = require('../models/center.model');
const Student = require('../models/student.model');
const Exam = require('../models/exam.model');
const fs = require('fs')
const path = require('path');

const genericValidation = require('../utils/genericvalidation');

//create new Student

const createStudent = async (req, res, next) => {
    try {

        const examCode = req.params.id;

        const foundExam = await Exam.findOne({ examCode });
        if (!foundExam) return res.status(400).send({
            message: `Exam not Found , You can not create Student for this ExamCode  ${examCode}`
        }); //Exam Not Found

        if (foundExam != null) {

            req.body.examIds = foundExam._id;
            req.body.examCode = foundExam.examCode;

            if (req.file) {

                const relPath = path.join(__dirname, "../");

                var obj = {
                    name: req.file.filename,
                    desc: req.body.desc,
                    img: {
                        data: fs.readFileSync(path.join(__dirname, "../", '/upload/images/' + req.file.filename)),
                        contentType: `${req.file.mimetype}`
                    }
                }


                req.body.image = obj;


            } else {

                return res.status(422).send({
                    message: "Please upload an  Image file of type jpeg/jpg/png/gif",
                })

            }

            let examType = genericValidation.changeCaseFirstLetter(req.body.examType);
            req.body.examType = examType;

            let country = genericValidation.changeCaseFirstLetter(req.body.country);
            req.body.country = country;

            let state = genericValidation.changeCaseFirstLetter(req.body.state);
            req.body.state = state;

            let city = genericValidation.changeCaseFirstLetter(req.body.city);
            req.body.city = city;

            const zipcode = req.body.zipcode;

            if (genericValidation.validateZipCode(zipcode)) {
                req.body.zipcode = zipcode;
            }
            else {

                return res.status(422).send({
                    message: "ZipCode should be of 6 digits and should not contain any spaces",
                })

            }

            const phoneNumber = req.body.contactNumber;

            if (genericValidation.validatePhoneNumber(phoneNumber)) {
                req.body.contactNumber = phoneNumber;
            }
            else {

                return res.status(422).send({
                    message: "Contact Number should be of 10 digits, must starts with [6-9] and it should not contain any spaces",
                })

            }

            const email = req.body.email;

            if (genericValidation.ValidateEmail(email)) {
                req.body.email = email;
            }
            else {

                return res.status(422).send({
                    message: "Email entered is invalid. Please provide a valid email",
                })

            }


            const centerCode = req.body.centerCode;
            const foundCenter = await Center.findOne({ centerCode });
            if (!foundCenter) {
                res.send({
                    message: "Center not found ",

                })

            }
            else {

                let student = new Student(req.body);
                student = await student.save();
                //  res.redirect('/upload');

                res.send({
                    message: "Student Created",
                    profile_url: `http://localhost:3000/profile/${req.file.filename}`,
                    data: student
                })
            }

        }


    } catch (error) {
        return next(error)

    }
}

const updateStudent = async (req, res, next) => {
    try {

        const examCode = req.params.id;

        const foundExam = await Exam.findOne({ examCode });
        if (!foundExam) return res.status(400).send({
            message: `Exam not Found , You can not create Student for this ExamCode  ${examCode}`
        }); //Exam Not Found

        if (foundExam != null) {

            req.body.examIds = foundExam._id;
            req.body.examCode = foundExam.examCode;

            if (req.file) {
                    var obj = {
                    name: req.file.filename,
                    desc: req.body.desc,
                    img: {
                        data: fs.readFileSync(path.join(__dirname, "../", '/upload/images/' + req.file.filename)),
                        contentType: `${req.file.mimetype}`
                    }
                }


                req.body.image = obj;

            }
            else {

                return res.status(422).send({
                    message: "Uploaded File should be an Image of type jpeg/jpg/png/gif",
                })

            }

            let country = genericValidation.changeCaseFirstLetter(req.body.country);
            req.body.country = country

            let state = genericValidation.changeCaseFirstLetter(req.body.state);
            req.body.state = state;

            const zipcode = req.body.zipcode;

            if (genericValidation.validateZipCode(zipcode)) {
                req.body.zipcode = zipcode;
            }
            else {

                return res.status(422).send({
                    message: "ZipCode should be of 6 digits and should not contain any spaces",
                })

            }

            const phoneNumber = req.body.contactNumber;

            if (genericValidation.validatePhoneNumber(phoneNumber)) {
                req.body.contactNumber = phoneNumber;
            }
            else {

                return res.status(422).send({
                    message: "Contact Number should be of 10 digits, must starts with [6-9] and it should not contain any spaces",
                })

            }


            const enrollmentId = req.params.studentId;
            console.log("Student present :" + enrollmentId)
            const foundStudent = await Student.findOne({ "enrollmentId": enrollmentId });
            console.log("Student present :" + foundStudent)

            if (foundStudent) {
                const updatedStudent = await Student.findOneAndUpdate({ "enrollmentId": enrollmentId }, { $set: req.body }, { new: true });
                res.send({
                    message: " Student Updated",
                    data: updatedStudent
                })
            }
            else {

                res.send({
                    message: " Student not Found"

                })
            }

        }


    } catch (error) {
        return next(error)

    }
}

const getAllStudents = async (req, res, next) => {

    try {
        const examCode = req.params.id;

        const foundExam = await Exam.findOne({ examCode });
        if (!foundExam) return res.status(400).send({
            message: `Exam not Found `
        }); //Exam Not Found

       let students = [];
       students = await Student.find({ examCode: examCode });
        if (students.length > 0) {
           
            return res.status(200).send({
                message: "Success",
                data: students
            })
        }
        else {

            return res.status(404).send({
                message: "No Student Enrolled"
            })

        }

    } catch (error) {
        return next(error)

    }

}


//delete Student
const deleteStudent = async (req, res, next) => {
    try {

        const examCode = req.params.id;
        const enrollmentId = req.params.studentId;
        const examFound = await Exam.findOne({ examCode: examCode });
        if (!examFound) {
            return res.status(404).send({
                message: "Exam Record Not Found"
            })
        }
        else {

            await Student.findOneAndDelete({ "enrollmentId": enrollmentId })

            return res.status(200).send({
                message: "Student Deleted",

            })
        }
    } catch (error) {

        return next(error)

    }


}

//delete all Students
const deleteAllStudents = async (req, res, next) => {
    try {

        const examCode = req.params.id;
        // const centerCode = req.params.centerId;
        const examFound = await Exam.findOne({ examCode: examCode });
        if (!examFound) {
            return res.status(404).send({
                message: "Exam Record Not Found"
            })
        }
        else {
            
            await Student.deleteMany({ "examCode": examCode })

            return res.status(200).send({
                message: `All Students of Exam Code ${examCode}  are deleted`,

            })
        }
    } catch (error) {

        return next(error)

    }


}








module.exports = {
    createStudent,
    deleteStudent,
    updateStudent,
    getAllStudents,
    deleteAllStudents


};