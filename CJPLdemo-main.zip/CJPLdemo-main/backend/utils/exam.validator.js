const { body , validationResult } = require('express-validator');

//* validation rules
const examValidationRules = () => {
    return [

        body("examCode").isString().trim().notEmpty().withMessage("Please provide an Exam Code "), 
        //CustomerCode can not be empty
        body("customerCode").isString().trim().notEmpty().withMessage("Please provide Customer Code and should be only Numbers").isNumeric().withMessage("Customer Code Should be only Numeric"), 
        //* name is required and must be string
        body("examType").isString().trim().notEmpty().withMessage("Please provide Exam Type").isAlpha('en-US').withMessage("Exam Type should contain only albhabets/letters"),
        body("examStatus").isString().trim().notEmpty().withMessage("Please provide Exam Status either Active or Inactive"),
        body("examName").isString().trim().notEmpty().withMessage("Please provide Exam Name").isAlpha('en-US', {ignore: ' '}).withMessage("Exam Name should contain only albhabets/letters"), //* on error this message is sent.
        body("examStartDate").isString().trim().withMessage('Plesae provide examStartDate').isDate().withMessage('examStartDate be a valid date YYYY-MM-DD')  ,
        body("examEndDate").isString().trim().withMessage('Plesae provide examExamEndDate').isDate().withMessage('examEndDate be a valid date YYYY-MM-DD')  ,
        body("examType").isString().optional(),
      ];
  };

  const examUpdateValidationRules = () => {
    return [
       // body("examCode").isString.withMessage("Exam Code can not be updated, Please remove Exam Code"),
        //* name is required and must be string
        body("examType").isString().trim().notEmpty().withMessage("Please provide Exam Type").isAlpha('en-US').withMessage("Exam Type should contain only albhabets/letters"),
        body("examStatus").isString().trim().notEmpty().withMessage("Please provide Exam Status either Active or Inactive"),
        body("examName").isString().trim().notEmpty().withMessage("Please provide Exam Name").isAlpha('en-US', {ignore: ' '}).withMessage("Exam Name should contain only albhabets/letters"), //* on error this message is sent.
        body("examStartDate").isString().trim().withMessage('Plesae provide examStartDate').isDate().withMessage('examStartDate be a valid date YYYY-MM-DD')  ,
        body("examEndDate").isString().trim().withMessage('Plesae provide examExamEndDate').isDate().withMessage('examEndDate be a valid date')  ,
        body("examType").isString().optional(),
      ];
  };

  //* validated the variables present inside req.body according to above validation rules
const validateExam = (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
      return next(); // if no errors are found it proceeds to the next function
    }
    const extractedErrors = [];
    errors.array().map((err) => extractedErrors.push({ [err.param]: err.msg })); // maps the error inside the extractedErrors array
    return res.status(422).json({
      errors: extractedErrors,
    });
  };

module.exports = { examValidationRules ,examUpdateValidationRules, validateExam } ;