const { body , validationResult } = require('express-validator');

const validatePhoneNumber = (inputPhone) => {
    const regxPhone = /^[6-9]\d{9}$/;
    return regxPhone.test(inputPhone);
}

const validateZipCode = (inputZipCode) => {
    const regxZip = /^[1-9][0-9]{5}$/;
    return regxZip.test(inputZipCode);
}

const validateName = (inputName) => {
    const regxName = /^[a-zA-Z ]*$/;
    return regxName.test(inputName);
}

const  ValidateEmail = (email) =>
{
    const regxEmail = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
    return regxEmail.test(email);
}

const changeCaseFirstLetter = (inputString) => {
    if (typeof inputString === 'string') {
        return inputString.charAt(0).toUpperCase() + inputString.slice(1).toLowerCase();
    }
    return null;
}




  //* validated the variables present inside req.body according to above validation rules
  const validate = (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
      return next(); // if no errors are found it proceeds to the next function
    }
    const extractedErrors = [];
    errors.array().map((err) => extractedErrors.push({ [err.param]: err.msg })); // maps the error inside the extractedErrors array
    return res.status(422).json({
      errors: extractedErrors,
    });
  };

module.exports = {
    validatePhoneNumber,
    validateZipCode,
    validateName,
    ValidateEmail,
    changeCaseFirstLetter,
    validate
};