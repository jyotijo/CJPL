const { body , validationResult } = require('express-validator');

//* validation rules
const createCenterValidationRules = () => {
    return [

        //CenterCode can not be empty
        body("centerCode").isString().trim().notEmpty().withMessage("Please provide Center Code "),
        //.isNumeric().withMessage("Center Code Should be only Numeric"), 
        body("centerStatus").isString().trim().notEmpty().withMessage("Please provide Center Status either Active or Inactive"),
        body("centerName").isString().trim().notEmpty().withMessage("Please provide Center Name"),
        //.isAlpha('en-US', {ignore: ' '}).withMessage("Center Name should contain only albhabets/letters"), //* on error this message is sent.
        body("examDate").isString().trim().withMessage('Plesae provide Exam Date').isDate().withMessage('ExamDate should be a valid date of format YYYY-MM-DD')  ,
        body("centerHead").isString().trim().notEmpty().withMessage("Please provide CenterHead ").isAlpha('en-US', {ignore: ' '}).withMessage("CenterHead should contain only albhabets/letters"),
        body("centerAddress.address").isString().trim().notEmpty().withMessage("Please provide Address"),
        body("centerAddress.city").isString().trim().notEmpty().withMessage("Please provide City Name").isAlpha('en-US', {ignore: ' '}).withMessage("City Name should contain only albhabets/letters"),
        body("centerAddress.state").isString().trim().notEmpty().withMessage("Please provide State").isAlpha('en-US', {ignore: ' '}).withMessage("State Name should contain only albhabets/letters"),
        body("centerAddress.zipcode").isString().notEmpty().withMessage("Please provide Zipcode").isNumeric().withMessage("Zipcode should contain only Numbers"),
        body("centerAddress.country").isString().trim().notEmpty().withMessage("Please provide Country").isAlpha('en-US', {ignore: ' '}).withMessage("Country should contain only albhabets/letters"),
        body("contactPersonName").isString().trim().notEmpty().withMessage("Please provide Contact Person Name").isAlpha('en-US', {ignore: [' ','.']}).withMessage("Contact Person Name should contain only albhabets/letters"),
        body("contactNumber").isString().notEmpty().withMessage("Please provide Contact Number").isNumeric().withMessage("Contact Number should contain only Numbers"),
      ];
  };

  const updateCenterValidationRules = () => {
    return [
      body("centerStatus").isString().trim().notEmpty().withMessage("Please provide Center Status either Active or Inactive"),
      body("centerName").isString().trim().notEmpty().withMessage("Please provide Center Name"),
      //.isAlpha('en-US', {ignore: ' '}).withMessage("Center Name should contain only albhabets/letters"), //* on error this message is sent.
      body("examDate").isString().trim().withMessage('Plesae provide Exam Date').isDate().withMessage('ExamDate should be a valid date of format YYYY-MM-DD')  ,
      body("centerHead").isString().trim().notEmpty().withMessage("Please provide CenterHead ").isAlpha('en-US', {ignore: ' '}).withMessage("CenterHead should contain only albhabets/letters"),
      body("centerAddress.address").isString().trim().notEmpty().withMessage("Please provide Address"),
      body("centerAddress.city").isString().trim().notEmpty().withMessage("Please provide City Name").isAlpha('en-US', {ignore: ' '}).withMessage("City Name should contain only albhabets/letters"),
      body("centerAddress.state").isString().trim().notEmpty().withMessage("Please provide State").isAlpha('en-US', {ignore: ' '}).withMessage("State Name should contain only albhabets/letters"),
      body("centerAddress.zipcode").isString().trim().notEmpty().withMessage("Please provide Zipcode").isNumeric().withMessage("Zipcode should contain only Numbers").isLength({max:6}).withMessage("Zipcode should be of 6 digit"),
      body("centerAddress.country").isString().trim().notEmpty().withMessage("Please provide Country").isAlpha('en-US', {ignore: ' '}).withMessage("Country should contain only albhabets/letters"),
      body("contactPersonName").isString().trim().notEmpty().withMessage("Please provide Contact Person Name").isAlpha('en-US', {ignore:  [' ','.']}).withMessage("Contact Person Name should contain only albhabets/letters"),
      body("contactNumber").isString().notEmpty().withMessage("Please provide Contact Number").isNumeric().withMessage("Contact Number should contain only Numbers"),
    
      ];
  };

  const validateAddress = [
   // body('name').not().isEmpty().isString(),
    //body('address').optional(),
    body('centerAddress.address').custom((value,{req}) => {
      if(req.body.centerAddress != undefined && req.body.centerAddress.address == undefined){
         throw new Error("Address is required for the address");
      }
      else {
        return true;
      }
    })
  ];

  //* validated the variables present inside req.body according to above validation rules
const validateCenter = (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
      return next(); // if no errors are found it proceeds to the next function
    }
    const extractedErrors = [];
    errors.array().map((err) => extractedErrors.push({ [err.param]: err.msg })); // maps the error inside the extractedErrors array
    return res.status(422).json({
      errors: extractedErrors,
    });
  };

module.exports = { createCenterValidationRules ,updateCenterValidationRules, validateCenter,} ;