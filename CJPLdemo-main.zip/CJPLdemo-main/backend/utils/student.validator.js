const { body , validationResult } = require('express-validator');

//* validation rules
const createStudentValidationRules = () => {
    return [

        //CenterCode can not be empty
        body("centerCode").isString().trim().notEmpty().withMessage("Please provide Center Code "),
        body("examType").isString().trim().notEmpty().withMessage("Please provide Exam Type").isAlpha('en-US').withMessage("Exam Type should contain only albhabets/letters"),
        body("examShift").isString().trim().notEmpty().withMessage("Please provide Exam Shift").isAlphanumeric().withMessage("Exam Type is alpha-numeric"),
        body("enrollmentId").isString().trim().notEmpty().withMessage("Please provide Enrollment ID").isAlphanumeric().withMessage("Enrollment ID is alpha-numeric"),
        body("studentName").isString().trim().notEmpty().withMessage("Please provide Student Name").isAlpha('en-US', {ignore: ' '}).withMessage("Student Name should contain only albhabets/letters"),
        body("parentName").isString().trim().notEmpty().withMessage("Please provide Parent Name").isAlpha('en-US', {ignore: [' ','.']}).withMessage("Parent Name should contain only albhabets/letters"),
        body("examDate").isString().trim().withMessage('Plesae provide Exam Date').isDate().withMessage('ExamDate should be a valid date of format YYYY-MM-DD')  ,
        body("address").isString().trim().notEmpty().withMessage("Please provide Address"),
        body("city").isString().trim().notEmpty().withMessage("Please provide City Name").isAlpha('en-US', {ignore: ' '}).withMessage("City Name should contain only albhabets/letters"),
        body("state").isString().trim().notEmpty().withMessage("Please provide State").isAlpha('en-US', {ignore: ' '}).withMessage("State Name should contain only albhabets/letters"),
        body("zipcode").isString().notEmpty().withMessage("Please provide Zipcode").isNumeric().withMessage("Zipcode should contain only Numbers"),
        body("country").isString().trim().notEmpty().withMessage("Please provide Country").isAlpha('en-US', {ignore: ' '}).withMessage("Country should contain only albhabets/letters"),
       
        body("contactNumber").isString().notEmpty().withMessage("Please provide Contact Number").isNumeric().withMessage("Contact Number should contain only Numbers"),
        body("email").trim().notEmpty().withMessage('Please provide email')
        .isEmail().withMessage('Please provide a valid email')
        .normalizeEmail()
        .toLowerCase(),
      ];
  };

  const updateStudentValidationRules = () => {
    return [
      body("centerStatus").isString().trim().notEmpty().withMessage("Please provide Center Status either Active or Inactive"),
      body("centerName").isString().trim().notEmpty().withMessage("Please provide Center Name"),
      //.isAlpha('en-US', {ignore: ' '}).withMessage("Center Name should contain only albhabets/letters"), //* on error this message is sent.
      body("examDate").isString().trim().withMessage('Plesae provide Exam Date').isDate().withMessage('ExamDate should be a valid date of format YYYY-MM-DD')  ,
      body("centerHead").isString().trim().notEmpty().withMessage("Please provide CenterHead ").isAlpha('en-US', {ignore: ' '}).withMessage("CenterHead should contain only albhabets/letters"),
      body("centerAddress.address").isString().trim().notEmpty().withMessage("Please provide Address"),
      body("centerAddress.city").isString().trim().notEmpty().withMessage("Please provide City Name").isAlpha('en-US', {ignore: ' '}).withMessage("City Name should contain only albhabets/letters"),
      body("centerAddress.state").isString().trim().notEmpty().withMessage("Please provide State").isAlpha('en-US', {ignore: ' '}).withMessage("State Name should contain only albhabets/letters"),
      body("centerAddress.zipcode").isString().trim().notEmpty().withMessage("Please provide Zipcode").isNumeric().withMessage("Zipcode should contain only Numbers").isLength({max:6}).withMessage("Zipcode should be of 6 digit"),
      body("centerAddress.country").isString().trim().notEmpty().withMessage("Please provide Country").isAlpha('en-US', {ignore: ' '}).withMessage("Country should contain only albhabets/letters"),
      body("contactPersonName").isString().trim().notEmpty().withMessage("Please provide Contact Person Name").isAlpha('en-US', {ignore:  [' ','.']}).withMessage("Contact Person Name should contain only albhabets/letters"),
      body("contactNumber").isString().notEmpty().withMessage("Please provide Contact Number").isNumeric().withMessage("Contact Number should contain only Numbers"),
    
      ];
  };

  const validateAddress = [
   // body('name').not().isEmpty().isString(),
    //body('address').optional(),
    body('centerAddress.address').custom((value,{req}) => {
      if(req.body.centerAddress != undefined && req.body.centerAddress.address == undefined){
         throw new Error("Address is required for the address");
      }
      else {
        return true;
      }
    })
  ];


module.exports = { createStudentValidationRules ,updateStudentValidationRules} ;