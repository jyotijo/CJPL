

const router = require('express').Router();

router.get("/",(req,res)=>{
    return res.status(200).send({
        message: "WELCOME TO CJPL PROJECT",
        
    })
})

module.exports = router;