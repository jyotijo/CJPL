const express = require('express');
const router = express.Router();
const examController = require('../../controllers/exam.controller');
const centerController = require('../../controllers/center.controller');
const studentController = require('../../controllers/student.controller');
const {examValidationRules, examUpdateValidationRules,validateExam} = require('../../utils/exam.validator');
const centerValidator = require('../../utils/center.validator');
const studentValidator = require('../../utils/student.validator');
const genericValidation = require('../../utils/genericvalidation');
const {upload} = require('../../middlewares/fileupload');
const {verifyRoles} = require('../../middlewares/verifyRoles');

//routes for Exam
router.post('/',verifyRoles('superadmin', 'admin'),examValidationRules(), validateExam, examController.createNewExam);
router.put('/:id',verifyRoles('superadmin', 'admin'),examUpdateValidationRules(), validateExam, examController.updateSingleExam);
router.delete('/:id',verifyRoles('superadmin', 'admin'), examController.deleteSingleExam);

//routes for center
router.post('/:id/centers', centerValidator.createCenterValidationRules(),centerValidator.validateCenter,centerController.createCenter);
router.get('/:id/centers',centerController.getAllCenter)
router.put('/:id/centers/:centerId', centerValidator.updateCenterValidationRules(), centerValidator.validateCenter,centerController.updateCenter);
router.delete('/:id/centers/:centerId', centerController.deleteCenter);
router.delete('/:id/centers', centerController.deleteAllCenter);

//routes for Student
router.post('/:id/students',upload,studentValidator.createStudentValidationRules(),genericValidation.validate,studentController.createStudent);

router.get('/:id/students',studentController.getAllStudents)
router.put('/:id/students/:studentId',upload,studentValidator.updateStudentValidationRules(),genericValidation.validate,studentController.updateStudent);
router.delete('/:id/students/:studentId', studentController.deleteStudent);

module.exports = router;