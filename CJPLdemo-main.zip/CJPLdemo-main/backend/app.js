const express = require('express');
const bodyParser = require('body-parser');
//const craeteHttpError = require('http-errors');
const morgan = require('morgan');
const app = express();

const connectDB = require('./config/db.config');
require('dotenv').config();
const errorHandler = require('./middlewares/errors');
const { unless } = require('express-unless');
const fs = require('fs');
const path = require('path');

//app.use(morgan('dev'));
app.use(express.json());

//view profile image
app.use('/profile',express.static('./upload/images'))
//app.use(bodyParser.urlencoded());
app.use(bodyParser.urlencoded({ extended: true }));

// Set EJS as templating engine 
app.set("view engine", "ejs");

// routes
app.use('/', require('./routes/root'));
app.use('/exams', require('./routes/api/exams.route'));

//error handler
app.use(errorHandler);

const port = process.env.SERVER_PORT || 5000;

const start = async () => {
  try {
    await connectDB(process.env.MONGO_URI);
    app.listen(port, () =>
      console.log(`Server is listening on port ${port}...`)
    );
  } catch (error) {
    console.log(error);
  }
};

start();