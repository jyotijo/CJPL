
const ExamModel = require('../models/exam.model');
const examService = require('../services/exam.services');

//Create New Exam 

const createNewExam = async (req, res,next) => {
    try {
            examService.createNewExam(req,res,next);
        
    } catch (error) {
             next(error);
   
    }
}

//update an Exam

const updateSingleExam = async (req, res,next) => {
    try {
       
        examService.updateSingleExam(req,res,next);
    
    } catch (error) {
            next(error);

    }
}

//delete an Exam

const deleteSingleExam = async (req, res,next) => {

    try {
        examService.deleteSingleExam(req,res,next);
    
    } catch (error) {
            next(error);

    }

}


    module.exports = {
        createNewExam,
        updateSingleExam,
        deleteSingleExam,
    }