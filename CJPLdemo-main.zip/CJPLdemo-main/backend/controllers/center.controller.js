
const ExamModel = require('../models/exam.model');
const centerService = require('../services/center.services');

//Create New Center 

const createCenter = async (req, res,next) => {
    try {
        centerService.createCenter(req,res,next);
        
    } catch (error) {
             next(error);
   
    }
}

//get all centers

const getAllCenter = async (req, res,next) => {
    try {
        centerService.getAllCenter(req,res,next);
        
    } catch (error) {
             next(error);
   
    }
}

//update Center

const updateCenter = async (req, res,next) => {
    try {
       
        centerService.updateCenter(req,res,next);
    
    } catch (error) {
            next(error);

    }
}

//delete an Center

const deleteCenter = async (req, res,next) => {

    try {
        console.log("inside Center");
        centerService.deleteCenter(req,res,next);
    
    } catch (error) {
            next(error);

    }

}

//delete an Center

const deleteAllCenter = async (req, res,next) => {

    try {
        console.log("inside Center");
        centerService.deleteAllCenter(req,res,next);
    
    } catch (error) {
            next(error);

    }

}


    module.exports = {
        createCenter,
        updateCenter,
        deleteCenter,
        getAllCenter,
        deleteAllCenter
    }