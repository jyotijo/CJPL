
const ExamModel = require('../models/exam.model');
const Student = require('../models/student.model');
const studentService = require('../services/student.services');

//Create New Student

const createStudent = async (req, res,next) => {
    try {
        studentService.createStudent(req,res,next);
        
    } catch (error) {
             next(error);
   
    }
}

//get all Students

const getAllStudents = async (req, res,next) => {
    try {
        studentService.getAllStudents(req,res,next);
        
    } catch (error) {
             next(error);
   
    }
}

//update Student

const updateStudent = async (req, res,next) => {
    try {
       
        studentService.updateStudent(req,res,next);
    
    } catch (error) {
            next(error);

    }
}

//delete an Student

const deleteStudent = async (req, res,next) => {

    try {
        
        studentService.deleteStudent(req,res,next);
    
    } catch (error) {
            next(error);

    }

}

//delete all Students

const deleteAllStudents = async (req, res,next) => {

    try {
        
        studentService.deleteAllStudents(req,res,next);
    
    } catch (error) {
            next(error);

    }

}


    module.exports = {
        createStudent,
        updateStudent,
        deleteStudent,
        getAllStudents,
        deleteAllStudents
    }