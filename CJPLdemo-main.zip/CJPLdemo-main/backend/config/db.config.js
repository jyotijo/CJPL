const mongoose = require('mongoose')

//mongoose.Promise = global.Promise;

const connectDB = (url) => {
  mongoose.connect(url, function(err, db) {
    if(err) 
      throw err;
    else
    {
    console.log("Connected to MongoDB!");
    }
  },
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  {multi: true}
  )
}

module.exports = connectDB




