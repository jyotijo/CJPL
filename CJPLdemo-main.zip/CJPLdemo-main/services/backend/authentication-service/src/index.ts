import express from 'express';
import { json } from 'body-parser';
const mongoose = require('mongoose') ;

const app = express();
app.use(json());

app.get('/api/v1/auth',(req, res) => {
    return res.status(200).json({
        statusCode: 200,
        message: "The Attendance Authentication service is running successfully!"
    })
});

const mongoose_server = async () => {
    try {
        await mongoose.connect('mongodb://auth-mongo-service:27017/authentication', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }).then(() => console.log('MongoDB connected for authentication Service'));       
    } catch (err) {
        console.log(err)
    }
};

app.listen(4011, () => {
    console.log('listening on PORT {4011}');
});

mongoose_server();