import express from 'express';
import { json } from 'body-parser';
const mongoose = require('mongoose');

const app = express();
app.use(json());

app.get('/api/v1/cjpl',(req, res) => {
    return res.status(200).json({
        statusCode: 200,
        message: "The CJPL Management service is running successfully!"
    })
});

const mongoose_server = async () => {
    try {
        await mongoose.connect('mongodb://cjpl-mongo-service:27017/cjpl', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }).then(() => console.log('MongoDB connected for CJPL Management Service'));       
    } catch (err) {
        console.log(err)
    }
};

app.listen(4000, () => {
    console.log('listening on PORT {4000}');
});

mongoose_server();