Start-Job -ScriptBlock { kubectl port-forward service/users-mongo-service -n default 27018:27017 }
Start-Job -ScriptBlock { kubectl port-forward service/exams-mongo-service -n default 27012:27017 }
Start-Job -ScriptBlock { kubectl port-forward service/cjpl-mongo-service -n default 27014:27017 }
Start-Job -ScriptBlock { kubectl port-forward service/customers-mongo-service -n default 27015:27017 }
Start-Job -ScriptBlock { kubectl port-forward service/invigilate-mongo-service -n default 27016:27017 }
Start-Job -ScriptBlock { kubectl port-forward service/auth-mongo-service -n default 27011:27017 }

# Jobs are running in background
Write-Host "Congratulations yours files are running!"