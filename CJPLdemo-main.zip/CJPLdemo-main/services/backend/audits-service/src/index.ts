import express from 'express';
import { json } from 'body-parser';

const app = express();
app.use(json());

app.get('/api/v1/audits',(req, res) => {
    return res.status(200).json({
        statusCode: 200,
        message: "The Audits and Reports service is running successfully!"
    })
})

app.listen(3011, () => {
    console.log('listening on PORT {3011}');
})