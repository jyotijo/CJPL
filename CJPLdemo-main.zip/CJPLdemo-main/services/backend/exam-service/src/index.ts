import express from 'express';
import { json } from 'body-parser';
const mongoose = require('mongoose');

const app = express();
app.use(json());

app.get('/api/v1/exams',(req, res) => {
    return res.status(200).json({
        statusCode: 200,
        message: "The exam service is running successfully!"
    })
});

const mongoose_server = async () => {
    try {
        await mongoose.connect('mongodb://exams-mongo-service:27017/exams', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }).then(() => console.log('MongoDB connected for Exams Service'));       
    } catch (err) {
        console.log(err)
    }
};

app.listen(3005, () => {
    console.log('listening on PORT {3005}');
});

mongoose_server();