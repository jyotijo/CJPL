import express from 'express';
import { json } from 'body-parser';
const mongoose = require('mongoose');

const app = express();
app.use(json());

app.get('/api/v1/customers',(req, res) => {
    return res.status(200).json({
        statusCode: 200,
        message: "The Customer/Vendor service is running successfully!"
    })
})

const mongoose_server = async () => {
    try {
        await mongoose.connect('mongodb://customers-mongo-service:27017/customers-vendors', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }).then(() => console.log('MongoDB connected for Customers and Vendors Service'));       
    } catch (err) {
        console.log(err)
    }
};

app.listen(3006, () => {
    console.log('listening on PORT {3006}');
});

mongoose_server();