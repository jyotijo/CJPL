import { Message } from "node-nats-streaming";
import { Listener } from "./abstract-listner.event";
import { Subjects } from "./subjects.channel";
import { UserCreatedEventDto } from "./user-created-event.dto";

export class UserCreatedListner extends Listener<UserCreatedEventDto> {
    readonly subject = Subjects.UserCreated;
    queueGroupName = 'invigilators-service';

    onMessage(data: UserCreatedEventDto['data'],msg: Message) {
        console.log('Event Data!', data);
        console.log("What is my name? #",data.user);
        msg.ack();
    }
}