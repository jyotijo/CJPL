import { Subjects } from "./subjects.channel";

export interface UserCreatedEventDto {
    subject: Subjects.UserCreated;
    data: {
        id: string;
        user: string;
        role: string;
    };
}