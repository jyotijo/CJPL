import { Publisher } from "./abstract-publisher.event";
import { UserCreatedEventDto } from "./user-created-event.dto";
import { Subjects } from "./subjects.channel"; 

export class UserCreatedPublisher extends Publisher<UserCreatedEventDto> {
    readonly subject = Subjects.UserCreated;
}