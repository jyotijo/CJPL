import nats from 'node-nats-streaming';
import { randomBytes } from 'crypto';
import { UserCreatedListner } from '../events/user-created-listner.event';

console.clear();

const client = nats.connect(
    'cjpl',
    randomBytes(4).toString('hex'), 
    {
        url: 'http://localhost:4222'
    }
);

// What if the service is about to close down....

client.on('connect', () => {
    console.log('listner connected to nats!');

    client.on('close', ()=>{
        console.log('NATS connection closed!');
        process.exit();
    });

    new UserCreatedListner(client).listen();
    
 });

// Gracefull closeing of the server....
process.on('SIGINT', () => client.close());
process.on('SIGTERM', () => client.close());




