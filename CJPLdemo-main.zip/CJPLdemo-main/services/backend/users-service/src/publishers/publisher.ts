import nats, { Stan } from 'node-nats-streaming';
import { UserCreatedPublisher } from '../events/user-created-publisher.event';

console.clear();

const client = nats.connect('cjpl', 'abc', {
    url: 'http://localhost:4222'
});


client.on('connect',async () => {
    console.log('Publisher connected to NATS!')

    const publisher = new UserCreatedPublisher(client);
    try {
        await publisher.publish({
            id: '12345',
            user: 'Paavan',
            role: 'Operator'
        });
    } catch (err) {
        console.error(err);
    }

//     const data = JSON.stringify({
//         id: '1234',
//         user: 'someuser',
//         role: 'operator'
//     });

//     client.publish('user:created',data, () => {
//         console.log('event published!')
//     }); 
});


