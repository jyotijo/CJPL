import mongoose from "mongoose";
import { Password } from "../utils/encrypt&hash";


//  * An interface that describes the properties
//  * that are required to create a new user.

enum Roles {
    'nd',
    'operator',
    'supervisor'
}

export interface user_attrs{
    user_name: string
    email: string,
    password: string,
    address: [address_attrs],
    contact_number: string,
    role: Roles
}

// * An interface that describes the properties 
// * that a User Model has....

interface user_model extends mongoose.Model<user_doc> {
    build(attrs: user_attrs): user_doc;
}

// * An interface that describes the properties 
// * that a user document has..

interface address_attrs {
    city: string,
    country: string,
    postcode: string,
    state: string,
    street_address: string
}

interface user_doc extends mongoose.Document {
    email: string;
    user_name: string;
    password: string;
    address: [address_attrs]
}

// * Validate an Email address..

const validate_postal = (postal: string) => {
    return true
}

const validate_email = (email: string) => {
    var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return re.test(email)
};

const address_schema = new mongoose.Schema({
    city: {
        type: String,
        required: [true, 'A user must provide a city.'],
        max: 250
    },
    country: {
        type: String,
        required: true,
        default: 'India',
        max: 250
    },
    postcode: {
        type: String,
        required: [true, 'User must provide Postal code of his city/locality!'],
        max: 10,
        validate: [validate_postal, 'The provided Postal code is invalid!']
    },
    state: {
        type: String,
        required: [true, 'User must provide a State Name'],
        max: 250
    },
    street_address: {
        type: String, 
        required: [true, 'Provide the house number and street Name or locality name.']  
    },
    user_uuid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user_model'
    }
}, {
    toJSON: {
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
        },
        versionKey: false
    }
});

// ! Schema for the the roles...

const roles_schema = new mongoose.Schema({
    role:{
        type: String,
        enum: ['admin', 'monitoring-admin','operator', 'supervisor', 'nd'],
        trim: true,
        required: true,
        default: 'nd'
    },
    description: {
        type: String
    },
    user_uuid: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'user_model'
    },
    admin_uuid: {
        type: mongoose.Schema.Types.ObjectId,
        requrired: false
    },
    created_at: {
        type: Date,
        default: Date.now()
    },
    updated_at: {
        type: Date,
        default: Date.now()
    }
})


const user_schema = new mongoose.Schema({

    email: {
        type: String,
        trim: true,
        lowercase: true,
        unique: true,
        required: [true, 'Email address is a Required field!'],
        validate: [validate_email, 'Please provide a valid Email address!'],
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please fill a valid email address']
    },
    user_name: {
        type: String,
        required: true,
        trim: true
    },
    password: {
        type: String,
        required: true
    },
    address: {
        type: [address_schema],
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now(),
    },
    contact_number: {
        type: String,
        max: [12, 'the provided contact number is wrong'],
        trim: true,
        required: true
    },
    role: {
        type: roles_schema,
    },
    user_role: {
        type: String,
        required: true,
        enum: ['operator', 'supervisor', 'invigilator', 'nd'],
        default: 'nd'
    },
    is_active: {
        type: Boolean,
        default: false
    },
    updated_at: {
        type: Date,
        default: Date.now()
    }
}, {
    toJSON: {
        transform(doc, ret) {
            delete ret.password;
            ret.id = ret._id;
            delete ret._id;
        },
        versionKey: false
    }
});

// ! all the mongoose middleware function will have an es5 syntax instead of es6...

user_schema.pre('save', async function(done) {
    if (this.isModified('password')) {
        const hashed = await Password.toHash(this.get('password'));
        this.set('password', hashed);
    }
    done();
});

// ! Here we need this function to create a new document with TS...
user_schema.statics.build = (attrs: user_attrs) => {
    return new User(attrs);
}

const User = mongoose.model<user_doc, user_model>('user_model', user_schema);

// ! To create a NEW DOCUMENT use model.build command instead of new Model({})
export {User};

/*
    * The Tasks will be decided based on the roles...
    * The access to services will be provided based on the Roles of the User.
    * For instance CJPL-admin....
        -- ! if the role is cjpl-admin should have access to 
                cjpl-service.
        -- ! After the exam change the role to 'nd'.
        -- ! 

*/