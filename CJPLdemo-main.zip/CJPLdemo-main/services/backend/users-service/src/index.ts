const express = require('express');
const morgan = require('morgan');
const mongoose = require('mongoose');
const cookie_session = require('cookie-session');
const user_router = require( './user-routes/users.routes'); 
const service_router = require('./user-routes/user-service.routes');
import { errorHandler } from "@eveniontechnologies/common";


const app = express();

app.set('trust proxy', true);

app.use(morgan('dev'));

app.use(express.json());


app.use(
    cookie_session({
        signed: false,
        secure: true
    })
)

app.use('/api/v1/users', user_router)
app.use('/api/v1/user-service', service_router)
app.use(errorHandler);

if (!process.env.JWT_KEY){
    throw new Error('jwt must be defined!')
};

const mongoose_server = async () => {
    try {
        await mongoose.connect('mongodb://users-mongo-service:27017/users', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }).then(() => console.log('MongoDB connected for users-service'));       
    } catch (err) {
        console.log(err)
    }
};

app.listen(3000, () => {
    console.log('listening on PORT 3000 !!!');
});

mongoose_server();