import express from 'express';
const userController = require('./../user-controller/currentuser.controller');
const signupController = require('./../user-controller/signup.controller');
const signinController = require('./../user-controller/signin.controller');
const signoutController = require('./../user-controller/signout.controller');
import {currentUser} from '@eveniontechnologies/common';

const router = express.Router();

router
    .route('/')
    .get(userController.users_service);

router
    .route('/currentuser')
    .get(currentUser,userController.current_user);

router
    .route('/signup')
    .post(signupController.user_signup)

router
    .route('/signin')
    .post(signinController.user_signin)

router
    .route('/signout')
    .post(signoutController.user_signout);


module.exports = router;