import express from 'express';
const userController = require('./../user-controller/currentuser.controller');

const router = express.Router();

router
    .route('/')
    .get(userController.users_service);


module.exports = router;