import { Request, Response } from 'express';

exports.users_service = (req: Request, res: Response) => {
    return res.status(200).json({
        statusCode: 200,
        message: "The User Service is running successfully with skaffold in it!"
    })
};

exports.current_user = (req: Request, res: Response) => {
    console.log('currentUser in controller', req.currentUser, req.headers['auth-header-user']);

    if (!req.currentUser) {
        return res.status(401).json({
            currentUser: null
        });
    }
    return res.status(200).json({
        statusCode: 201,
        currentUser: req.currentUser 
    });
}