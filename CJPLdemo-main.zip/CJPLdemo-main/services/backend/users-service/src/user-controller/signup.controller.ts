import { User, user_attrs } from "../user-model/user.model";
import { Request, Response } from "express";
import jwt from 'jsonwebtoken';

exports.user_signup = async (req: Request, res: Response) => {
    const {email} = req.body;
    console.log(req.body);
    const existing_user = await User.findOne({email});
    let data:user_attrs = req.body;
    if (existing_user) {
        console.log('Email in user');
        return res.status(401).json({
            status_code: 401,
            message: 'User already exists!'
        });   
    }
    const new_user = User.build(data)
    await new_user.save();

    // * Generate the J-Token and set on session.
    
    const user_jwt = jwt.sign({
        id: new_user.id,
        email: new_user.email
    }, process.env.JWT_KEY!);

    req.session = {
        jwt: user_jwt
    };

    return res.status(201).json({
        status_code: 201,
        message: 'user created successfully!',
        new_user
    });
}