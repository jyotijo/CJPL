import express, {Request, Response, Router} from 'express';

exports.user_signout = (req:Request, res:Response) => {
    req.session = null;

    return res.status(200).json({})
}