import { Password } from './../utils/encrypt&hash';
import express, {Request, Response} from 'express';
import { User } from '../user-model/user.model';
import jwt from 'jsonwebtoken';
import { BadRequestError } from '@eveniontechnologies/common';


exports.user_signin = async (req: Request, res: Response) => {
    const {email, password} = req.body;
    console.log(email, password);
    const existing_user = await User.findOne({email});
    console.log("I am the existing user!", existing_user);
    if (!existing_user) {
        throw new BadRequestError('Bad Request Error!');
    }

    const password_match = await Password.compare(
        existing_user
        .password, password
    );

    if(!password_match) {
        throw new BadRequestError('Invalid Credentials!');
    }

    // * Generate the J-Token and set on session.
    
    const user_jwt = jwt.sign({
        id: existing_user.id,
        email: existing_user.email
    }, process.env.JWT_KEY!);

    req.session = {
        jwt: user_jwt
    };


    return res.status(200).json({
            status: 'User Signed In Successfully!',
            statusCode: 200,
            existing_user
    });
}